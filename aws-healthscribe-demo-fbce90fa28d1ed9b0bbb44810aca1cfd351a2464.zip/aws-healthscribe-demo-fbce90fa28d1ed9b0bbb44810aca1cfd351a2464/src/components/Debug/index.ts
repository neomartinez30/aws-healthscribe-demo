import Debug from './Debug';

export default Debug;
