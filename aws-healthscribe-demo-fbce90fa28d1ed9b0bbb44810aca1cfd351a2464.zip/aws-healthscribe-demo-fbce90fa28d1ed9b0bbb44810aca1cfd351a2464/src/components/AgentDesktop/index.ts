import AgentDesktop from './AgentDesktop';

export default AgentDesktop;