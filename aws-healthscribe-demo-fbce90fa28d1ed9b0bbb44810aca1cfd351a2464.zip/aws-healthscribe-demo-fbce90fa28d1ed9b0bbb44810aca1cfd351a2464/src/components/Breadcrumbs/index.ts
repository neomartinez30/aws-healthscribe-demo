import Breadcrumbs from './Breadcrumbs';

export default Breadcrumbs;
