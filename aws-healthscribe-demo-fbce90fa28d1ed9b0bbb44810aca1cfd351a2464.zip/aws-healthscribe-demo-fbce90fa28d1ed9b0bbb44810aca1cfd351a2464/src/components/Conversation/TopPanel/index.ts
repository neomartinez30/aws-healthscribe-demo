import TopPanel from './TopPanel';

export default TopPanel;
