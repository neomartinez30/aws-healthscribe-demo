import ViewOutput from './ViewOutput';

export default ViewOutput;
