import RightPanel from './RightPanel';

export default RightPanel;
