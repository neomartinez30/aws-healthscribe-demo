import PatientInsights from './patientinsights';

export default PatientInsights;