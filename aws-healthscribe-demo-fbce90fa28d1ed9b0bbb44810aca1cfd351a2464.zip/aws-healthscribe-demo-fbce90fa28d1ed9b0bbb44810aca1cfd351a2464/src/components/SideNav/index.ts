import SideNav from './SideNav';

export default SideNav;
