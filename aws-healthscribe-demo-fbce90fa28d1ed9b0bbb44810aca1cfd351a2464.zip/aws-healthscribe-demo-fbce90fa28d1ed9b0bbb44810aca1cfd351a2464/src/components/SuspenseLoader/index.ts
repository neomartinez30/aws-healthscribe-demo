import SuspenseLoader from './SuspenseLoader';

export default SuspenseLoader;
