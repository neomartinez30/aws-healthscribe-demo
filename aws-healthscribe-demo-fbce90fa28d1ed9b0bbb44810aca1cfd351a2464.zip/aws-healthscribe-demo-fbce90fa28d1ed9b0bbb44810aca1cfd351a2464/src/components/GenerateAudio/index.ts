import GenerateAudio from './GenerateAudio';

export default GenerateAudio;
